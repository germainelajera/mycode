import { Box, Button} from "@mui/material";
import { Stack } from "@mui/system";

type NavProps = {
    children: React.ReactNode;
}

export default function CheckMedHistory (prop: NavProps){
    return (
        <div>
            <div>
                {prop.children}
            </div>

            <h1 style={{ color: "#FF4B4B", marginBottom: "50px" }}>
                Medical Records
            </h1>

            <Button variant="contained" sx={{ bgcolor: "#FF4B4B", marginTop: "20px", position:"absolute", right:"150px"}}>
                Filter by Date
            </Button>

            <Stack >
                <Box>
                    red red
                </Box>
            </Stack>
        </div>
    )
}