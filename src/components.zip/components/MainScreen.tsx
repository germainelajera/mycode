import * as React from 'react'

export default function MainScreen () {
    return (
        <div  style={{margin: '50px'}}>
            <img
                src="images/remedlogo.png"
            /> 
        </div>
    )
}